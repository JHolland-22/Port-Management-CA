/*package fileio;

import com.example.LinkyList.LinkyList;
import com.example.LinkyList.Port;

import java.io.FileReader;
import java.util.Formatter;
import java.util.LinkedList;
import java.util.Scanner;

public class FileIO {


    private static void writeFile(String fileNameStr, LinkyList<Port> namesLinkedList) {
        try {

            Formatter outFile = new Formatter(fileNameStr);

            for (int k = 0; k < namesLinkedList.size(); k++) ;
            {
                outFile.format(namesLinkedList.get(k) + "\n");

            }
            outFile.close();
        } catch (Exception err) {
            System.out.println("ERROR: could not write file");

            err.printStackTrace();
        }
    }


    private static LinkedList<Port> readFile(String fileNameStr) {
        LinkedList<Port> allPorts = null;

        try {


            Scanner inFile = new Scanner(new FileReader(fileNameStr));

            allPorts = new LinkedList<>();

            while (inFile.hasNext() == true) {
                allPorts.add(inFile.next());

            }
            inFile.close();


        } catch (Exception err) {
            System.out.println("ERROR: could not write file");

            err.printStackTrace();

        }
        return allPorts;

    }



    public static void main(String [] args)
    {
      //Todo code application logic here
        //todo create a linked list and add data to it
        //todo write the linked list to file
        //todo clear the linked list
        //todo read in the linked list
        //todo display the linked list


      LinkyList<Port> allPorts =  new LinkyList<Port>();
      writeFile ("file.txt", allPorts);



    }

}

 */
