module com.example.portmanagment {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.portmanagment to javafx.fxml;

    exports com.example.portmanagment;
    opens resources to javafx.fxml;
    exports resources;
}