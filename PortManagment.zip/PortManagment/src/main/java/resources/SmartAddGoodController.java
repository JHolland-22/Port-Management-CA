package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;


public class SmartAddGoodController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button clearInputs;
    @FXML
    private ComboBox<Container> containerComboBox;
    @FXML
    private ComboBox<Pallet> palletComboBox;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private Button returnToMainMenu;


    @FXML
    void addButtonHandler(ActionEvent event) {
        // Get selected pallet and container

        Pallet pa = palletComboBox.getValue();
        Container c = containerComboBox.getValue();


        // Check if the container's value equals the pallet's unit value before adding

        if (palletComboBox.getValue().getUnitValue() == containerComboBox.getValue().getUnitValue()) {
            containerComboBox.getValue().allPallets.add(pa);

        c.allPallets.add(pa);
        allPallets.remove(pa);

        JOptionPane.showMessageDialog(null,
                "Success: Pallet added to suited Container!!\n" +
                        pa.toString() + c.toString());
     }else{
            // Show an error message if the unit values don't match
            JOptionPane.showMessageDialog(null, "Unit values do not match!");

    }{


        // Show an error message if either pallet or container is not selected
        JOptionPane.showMessageDialog(null, "Please select a Pallet and a Container");
    }

}


    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Populate container combo box items and set action for selected container
        for (Container container : allContainers) {
            containerComboBox.getItems().addAll(container);
        }
        containerComboBox.setOnAction(e -> printSelectedContainer());

        // Populate pallet combo box items and set action for selected pallet
        for (Pallet pallet : allPallets) {
            palletComboBox.getItems().addAll(pallet);
        }
        palletComboBox.setOnAction(e -> printSelectedPallet());

        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        for (Port port : allPorts) {
            portComboBox.getItems().addAll(port);
        }
        portComboBox.setOnAction(e -> printSelectedPort());

    }

    private void printSelectedPallet() {
        // Print the selected pallet
        System.out.println(palletComboBox.getValue());
    }

    private void printSelectedContainer() {
        // Print the selected container and its associated pallet
        System.out.println("Container: " + containerComboBox.getValue() +
                ", pallet: " + palletComboBox.getValue());
    }

    private void printSelectedShip() {
        for (Container container : shipComboBox.getValue().allContainers) {
            containerComboBox.getItems().addAll(container);
        }

        // Set an action event for the shipComboBox selection
        containerComboBox.setOnAction(e -> printSelectedContainer());

    }

    private void printSelectedPort() {
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());
    }

}






