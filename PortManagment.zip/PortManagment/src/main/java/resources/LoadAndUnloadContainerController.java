package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class LoadAndUnloadContainerController implements Initializable {


    @FXML
    private ComboBox<Container> containerCombBox;

    @FXML
    private Button loadButton;

    @FXML
    private TextArea loadedTextArea;

    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private ComboBox<Port> portComboBox;

    @FXML
    private Button unloadButton;


    @FXML
    void unloadButtonHandler(ActionEvent event) {
        Port p = portComboBox.getValue();
        Ship s = shipComboBox.getValue();
        Container c = containerCombBox.getValue();
        if (p != null && s != null && c != null)
        {

            s.allContainers.remove(c);
            p.allContainers.remove(c);

            allContainers.add(c);

            // Show a success message
            JOptionPane.showMessageDialog(null,
                    "Success: Removed Container!!\n" +
                            s.allContainers.toString() +
                            p.allContainers.toString());

        }else
        {
            // Show an error message if either pallet or container is not selected
            JOptionPane.showMessageDialog(null, "Please select a Pallet and a Container");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the portComboBox with items from HelloApplication.allPorts
        for (Container container : allContainers) {
            containerCombBox.getItems().addAll(container);
        }

        // Set an action event for the portComboBox selection
        containerCombBox.setOnAction(e -> printSelectedContainer());

        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        // Populate portComboBox with all available ports
        for (Port port : HelloApplication.allPorts) {
            portComboBox.getItems().addAll(port);
        }
        portComboBox.setOnAction(e -> printSelectedPort());
    }

    private void printSelectedContainer() {
        System.out.println(containerCombBox.getValue());


    }

    private void printSelectedPort() {
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());

    }

    private void printSelectedShip() {
        System.out.println(containerCombBox.getValue());
        for (Container container : shipComboBox.getValue().allContainers) {
            containerCombBox.getItems().addAll(container);
        }
        containerCombBox.setOnAction(e -> printSelectedContainer());

    }

    // Method to print the selected container and port


    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        // Load the MainMenu.fxml file and set it as the root
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene using the loaded root
        Scene scene = new Scene(root);

        // Get the stage from the event's source node and set the scene
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

        // Show the stage with the main menu scene
        stage.show();
    }
}


  /* listContainers();
        for (Pallet pallet : allPallets) {
            if (pallet == null) {
                String nameStr = "";
                String quantityStr = "";
                String getUnitValue = "";
                String totalWeightStr = "";
                String cubicFeetStr = "";
                    pallet = new Pallet(nameStr, quantityStr, getUnitValue, totalWeightStr, cubicFeetStr);
                HelloApplication.allPallets.add(pallet);
                System.out.println("pallet  " + pallet.getPalletId() +
                        " added to the container  " + container.getContainerId());
            } else {
                System.out.println("No container found.");
            }
        }

    }

        */

   /* @FXML
    void loadButtonHandler(ActionEvent event) {
        // Get the selected pallet and container from their respective ComboBoxes
        Pallet pa = palletCombBox.getValue();
        Container ct = containerCombBox.getValue();

        // Add the selected pallet to the list of pallets in the selected container
        ct.allPallets.add(pa);
        allPallets.remove(pa);


        // Show a success message indicating the pallet has been loaded into the container
        JOptionPane.showMessageDialog(null,
                "Success: Pallet Loaded To Container!!\n" +
                        ct.allPallets.toString());

        // Show an error message if either pallet or container is not selected
        {
            JOptionPane.showMessageDialog(null, "Please select a Pallet and a Container");
        }
    }



    */







