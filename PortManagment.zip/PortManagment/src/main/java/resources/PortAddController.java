package resources;
import com.example.portmanagment.Container;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;
import com.example.portmanagment.Port;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allPorts;

public class PortAddController implements Initializable {

    @FXML
    private Button addPortButton;
    @FXML
    private Button clearAllButton;
    @FXML
    private TextField codeTextField;
    @FXML
    private TextField countryTextField;
    @FXML
    private Button exitButton;
    @FXML
    private TextField nameTextField;
    @FXML
    private Label portCodeLabel;
    @FXML
    private Label portCountryLabel;
    @FXML
    private Label portNameLabel;


   // public static LinkyList<Port> allPorts =  new LinkyList<Port>();


    @FXML
    void addPortButtonHandler(ActionEvent event) {
        boolean dataValid = true;

        String nameStr = nameTextField.getText();
      //  String internationalPortCode = codeTextField.getText();
        //String country = countryTextField.getText();

        // Validation for Name field
        if (nameStr.length() == 0) {
            JOptionPane.showMessageDialog(null, " Error: Name cannot be blank");
            dataValid = false;
        }

      // if (dataValid == true) {
            // Validation for Code field
          //  if (internationalPortCode.length() == 0) {
            //    JOptionPane.showMessageDialog(null, " Error: Code cannot be blank");
             //   dataValid = false;
            //}


            Port port = null;

           // if (dataValid == true) {

                // Validation for Country field
             //   if (country.length() == 0) {
               //     JOptionPane.showMessageDialog(null, " Error: Country cannot be blank");
                 //   dataValid = false;
                //}


            if (dataValid == true) {
                port = new Port(nameStr); //internationalPortCode, country);
                allPorts.add(port);

                JOptionPane.showMessageDialog(null, "Success Port Added");
            }
        }




    @FXML
    void clearAllButtonHandler(ActionEvent event)
    {

     nameTextField.setText("");
     codeTextField.setText("");
     countryTextField.setText("");

    }

    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception , IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

      //  Utility.changeToScene(getClass(), event,"MainMenu.fxml");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        //allPorts = new LinkyList<Port>();
    }
}