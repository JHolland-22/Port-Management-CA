package resources;
import com.example.portmanagment.Good;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allGoods;

public class GoodAddController implements Initializable {

    @FXML
    private Button addGoodButton;
    @FXML
    private Button clearAllButton;
    @FXML
    private TextField gDescriptionTextField;
    @FXML
    private TextField goodTotalWeightTextField;
    @FXML
    private TextField goodQuantityTextField;
    @FXML
    private Button exitButton;
    @FXML
    private TextField gNameTextField;
    @FXML
    private TextField gIdTextField;
    @FXML
    private Label goodDescriptionLabel;
    @FXML
    private Label goodUnitVLabel;
    @FXML
    private Label goodNameLabel;
    @FXML
    private Label goodIdLabel;





    @FXML
    void addGoodButtonHandler(ActionEvent event) {
        boolean dataValid = true;

        // Retrieving input data from text fields and trimming any leading/trailing spaces
        String nameStr = gNameTextField.getText();
        String gDescriptionStr = gDescriptionTextField.getText();
        int gIdStr = Integer.parseInt(gIdTextField.getText());
        int goodQuantity = Integer.parseInt(goodQuantityTextField.getText());
        double totalWeightofGood = Double.parseDouble(goodTotalWeightTextField.getText());

        // Validation checks for the input fields
        if (nameStr.length() == 0) {
            JOptionPane.showMessageDialog(null, " Error: Name cannot be blank");
            dataValid = false;
        }

        if (dataValid) {
            if (gDescriptionStr.length() == 0) {
                JOptionPane.showMessageDialog(null, " Error: Description cannot be blank");
                dataValid = false;
            }
        }

        if (dataValid) {
            if (gIdStr == 0) {
                JOptionPane.showMessageDialog(null, " Error: Good ID cannot be blank");
                dataValid = false;
            }
        }

        if (dataValid) {
            if (goodQuantity == 0) {
                JOptionPane.showMessageDialog(null, " Error: Unit Value cannot be blank");
                dataValid = false;
            }
        }

        if (dataValid) {
            if (totalWeightofGood == 0) {
                JOptionPane.showMessageDialog(null, " Error: Unit Value cannot be blank");
                dataValid = false;
            }
        }

        // If all data is valid, create a new Good object and add it to the collection
        if (dataValid) {
            Good good = new Good(nameStr, gIdStr, gDescriptionStr, goodQuantity, totalWeightofGood);
            allGoods.add(good);
            JOptionPane.showMessageDialog(null, "Success: Good Added");
        }
    }


    @FXML
    void clearAllButtonHandler(ActionEvent event) {
        // Clearing the text content of various input fields
        gNameTextField.setText("");
        gDescriptionTextField.setText("");
        gIdTextField.setText("");
        goodQuantityTextField.setText("");
        goodTotalWeightTextField.setText("");
    }


    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene (main menu)
        stage.show();
    }


        @Override
        public void initialize (URL url, ResourceBundle resourceBundle){

        }

}

