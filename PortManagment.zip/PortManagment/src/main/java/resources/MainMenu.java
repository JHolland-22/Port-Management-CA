package resources;


import com.example.portmanagment.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;





public class   MainMenu extends Application implements Initializable {

    public static void main(String [] args){
        launch(args);
    }

    @FXML
    private Label label;

    private Button button;

    //port
    @FXML
    private Button addPortButton;
    @FXML
    private Button exitButton;
    @FXML
    private Button listPorts;


    //ship
    @FXML
    private Button addShipButton;
    @FXML
    private Button listShips;
    @FXML
    private Button addShipToAPortButton;

    //test data
    @FXML
    private Button addTestDataButton;


    //container
    @FXML
    private Button addContainerButton;
    @FXML
    private Button listContainers;
    @FXML
    private Button addContainerToAPortButton;
    @FXML
    private Button addContainerToAShipButton;

    //pallet
    @FXML
    private Button addPalletButton;
    @FXML
    private Button listPallets;
    @FXML
    private Button addPalletToAContainerButton;

    //good
    @FXML
    private Button addGoodButton;
    @FXML
    private Button listGoodss;
    @FXML
    private Button addGoodToAPalletButton;
    @FXML
    private Button loadAndUnloadButton;




    public void start(Stage stage) throws Exception {
        try {
            // Load the MainMenu.fxml file as the root node
            Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

            // Create a scene with the loaded root and set its dimensions to 600x600 pixels
            Scene scene = new Scene(root, 600, 600);

            // Set the created scene to the stage
            stage.setScene(scene);

            // Show the stage
            stage.show();

        } catch (Exception e) {
            // Print the stack trace if an exception occurs during loading or setting up the scene
            e.printStackTrace();
        } catch (IOException e) {
            // Wrap IOException in a RuntimeException and throw it
            throw new RuntimeException(e);
        }
    }






    //PORT
    @FXML
    void displayAllPortsHandler(ActionEvent event) throws Exception, IOException {
        // Load the FXML file named "PortDisplayAll.fxml" and create a root node
        Parent root = FXMLLoader.load((HelloApplication.class.getResource("PortDisplayAll.fxml")));

        // Create a new scene using the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage from the event's source
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        // Set the scene in the stage to the newly created scene
        stage.setScene(scene);

        // Show the stage with the updated scene
        stage.show();
    }

    @FXML
    void exitButtonHandler(ActionEvent event)
    {
        System.exit(0);//exit the app
    }

    @FXML
    void addPortButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load((HelloApplication.class.getResource("PortAdd.fxml")));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }







    //SHIP
    @FXML
    private void addShipButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ShipAdd.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void displayAllShipButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ShipDisplayAll.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void addShipToAPortButtonHandler(ActionEvent event) throws Exception , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ShipToPort.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayShipsAtAPortHandler(ActionEvent event)throws Exception, IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("DisplayAllShipsAtAPort.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }


    //CONTAINER
    @FXML
    private void addContainerButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ContainerAdd.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayAllContainerButtonHandler(ActionEvent event) throws Exception , IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ContainerDisplayAll.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void addContainerToAPortButtonHandler(ActionEvent event) throws Exception , IOException {

        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ContainerToPort.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    private void addContainerToAShipButtonHandler(ActionEvent event) throws Exception  , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("ContainerToShip.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayContainersAtAPortHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Container.class.getResource("DisplayAllContainersOnAPort.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    private void displayContainersAtAShipHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Container.class.getResource("DisplayAllContainerOnAShip.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }



    //PALLET

    @FXML
    private void addPalletButtonHandler(ActionEvent event) throws Exception  , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("PalletAdd.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayAllPalletButtonHandler(ActionEvent event) throws Exception , IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("DisplayAllPallets.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void addPalletToAContainerButtonHandler(ActionEvent event) throws Exception , IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("PalletToContainer.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayPalletsAtContainerHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Pallet.class.getResource("DisplayPalletsOnContainers.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }



    //GOODS
    @FXML
    private void addGoodButtonHandler(ActionEvent event) throws Exception  , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("GoodAdd.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayAllGoodButtonHandler(ActionEvent event) throws Exception  , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("DisplayAllGoods.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void addGoodToAPalletButtonHandler(ActionEvent event) throws Exception  , IOException{
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("GoodToPallet.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void displayGoodsAtPalletHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Good.class.getResource("DisplayGoodsOnPallet.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

    }






    //OTHER METHODS

    @FXML
    private void loadAndUnloadButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("LoadAndUnloadContainer.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

    }

    @FXML
    private void searchForAGoodButtonHandler(ActionEvent event)throws Exception , IOException
    {
            Parent root = FXMLLoader.load(Container.class.getResource("SearchForAGood.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

    }

    @FXML
    private void launchAShip(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Ship.class.getResource("LaunchAShip.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

    }


    @FXML
    private void removePalletButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Container.class.getResource("PalletRemove.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

    }

    @FXML
    private void LaunchDisplayHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(Ship.class.getResource("LaunchDisplay.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }


    @FXML
    private void smartAddGoodButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("SmartAddGood.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void drillDownButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("DrillDown.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }


    @FXML
    private void saveButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("Save.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void loadButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("loadContents.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void resetFacilityButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("Reset.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void ValueGoodsButtonHandler(ActionEvent event)throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("GoodValue.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}

//<Button fx:id="loadButton" mnemonicParsing="false" onAction="#loadButtonHandler" text="Load" GridPane.columnIndex="1" GridPane.rowIndex="23" />
//<Button fx:id="saveButton" mnemonicParsing="false" onAction="#saveButtonHandler" text="Save" GridPane.rowIndex="23" />
//<Button fx:id="loadButton" mnemonicParsing="false" onAction="#loadButtonHandler" text="Load" GridPane.columnIndex="1" GridPane.rowIndex="23" />
