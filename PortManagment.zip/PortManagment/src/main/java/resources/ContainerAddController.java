package resources;
import com.example.portmanagment.Container;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allContainers;

public class ContainerAddController implements Initializable {

    @FXML
    private Button addContainerButton;
    @FXML
    private Button clearAllButton;
    @FXML
    private TextField codeTextField;
    @FXML
    private TextField sizeTextField;
    @FXML
    private Button exitButton;
    @FXML
    private TextField nameTextField;
    @FXML
    private Label containerCodeLabel;
    @FXML
    private Label containerSizeLabel;
    @FXML
    private Label containerNameLabel;




    @FXML
    void addContainerButtonHandler(ActionEvent event) {
        // Flag to track the validity of input data
        boolean dataValid = true;

        // Retrieve and trim input from text fields
        String nameStr = nameTextField.getText().trim();
        String codeStr = codeTextField.getText().trim();
        String sizeStr = sizeTextField.getText().trim();

        // Check if the name is empty, display an error message if it is
        if (nameStr.length() == 0) {
            JOptionPane.showMessageDialog(null, " Error: Name cannot be blank");
            dataValid = false;
        }

        // Proceed with additional checks only if dataValid is still true
        if (dataValid == true) {
            // Check if the code is empty, display an error message if it is
            if (codeStr.length() == 0) {
                JOptionPane.showMessageDialog(null, " Error: Code cannot be blank");
                dataValid = false;
            }

            // Check if the size is empty, display an error message if it is
            if (dataValid == true) {
                if (sizeStr.length() == 0) {
                    JOptionPane.showMessageDialog(null, " Error: Size cannot be blank");
                    dataValid = false;
                }
            }
        }

        // Create a Container object only if all data is valid
        Container container = null;
        if (dataValid == true) {
            container = new Container(nameStr, codeStr, sizeStr);
        }

        // Add the Container to the collection if dataValid is true
        if (dataValid == true) {
            allContainers.add(container);

            JOptionPane.showMessageDialog(null, "Success Container Added");
        }
    }


    @FXML
    void clearAllButtonHandler(ActionEvent event) {
        // Clear the text fields by setting their text content to an empty string
        nameTextField.setText("");
        codeTextField.setText("");
        sizeTextField.setText("");
    }


    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the MainMenu.fxml file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // This method is called when the associated FXML file is loaded

        // Add initialization tasks here, such as setting default values, configuring UI, etc.
        // This method allows you to perform actions upon the initialization of the controller

        // For example, you might set default values for UI elements or load initial data here
        // Any setup or initialization logic for the controller can be placed within this method
    }

}
