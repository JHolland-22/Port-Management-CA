package resources;

import com.example.portmanagment.Container;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allContainers;

public class ContainerDisplayAllController implements Initializable {

    @FXML
    private Button returnToMainMenu;

    @FXML
    private TextArea displayTextArea;


    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the MainMenu.fxml file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // This method is called when the associated FXML file is loaded

        // Set up a string header for displaying Container information
        String outStr = "ID Name            Code               Size" + "\n" +
                "--------  --------------------   --------------------   --------------------" + "\n";

        // Iterate through allContainers to retrieve container information
        for (Container container : allContainers) {
            // Append each container's information to the output string
            outStr += container.toString() + "\n";
        }

        // Add a summary indicating the total number of containers found
        outStr += " -> " + allContainers.getSize() + " container found " + "\n";

        // Set the generated output string to the displayTextArea
        displayTextArea.setText(outStr);

        // Set the font style of the displayTextArea to Courier New with size 12
        displayTextArea.setFont(new Font("Courier New", 12));

        // Make the displayTextArea read-only
        displayTextArea.setEditable(false);
    }
}


