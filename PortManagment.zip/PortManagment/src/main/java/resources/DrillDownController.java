package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class DrillDownController implements Initializable {
    @FXML
    private Button returnToMainMenu;

    @FXML
    private TextArea displayTextArea;




    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize an empty string to accumulate information about different objects
        String outStr = "Drill Down of System " + "\n" + "--------  --------------------   --------------------   --------------------" + "\n";

        // Iterate through allPorts and append their details to outStr
        for (Port port : allPorts){
            outStr += port.toString() + "\n";
        }
        outStr += " -> " + allPorts.getSize() + " port found "+"\n";

        // Iterate through allShips and append their details to outStr
        for (Ship ship : allShips){
            outStr += ship.toString() + "\n";
        }
        outStr += " -> " + allShips.getSize() + " ship found "+"\n";

        // Iterate through allContainers and append their details to outStr
        for (Container container : allContainers){
            outStr += container.toString() + "\n";
        }
        outStr += " -> " + allContainers.getSize() + " container found "+"\n";

        // Iterate through allPallets and append their details to outStr
        for (Pallet pallet : allPallets){
            outStr += pallet.toString() + "\n";
        }
        outStr += " -> " + allPallets.getSize() + " pallet found "+"\n";

        // Iterate through allGoods and append their details to outStr
        for (Good good : allGoods){
            outStr += good.toString() + "\n";
        }
        outStr += " -> " + allGoods.getSize() + " good found "+"\n";


        outStr += " -> " + allContainers.getSize() + " Containers at a Port found\n";


        //displays all ships on ports

        for(Port p : HelloApplication.allPorts)
        {
            outStr += "\nPort: "+p.getName()+":\n";
            for(Ship s : p.allShips)
                outStr += s.toString()+"\n";
        }

        //displays all containers on ports
        for(Port p : HelloApplication.allPorts)
        {
            outStr += "\nPort: "+p.getName()+":\n";
            for(Container c : p.allContainers)
                outStr += c.toString()+"\n";
        }
        //displays all containers on ships

        for(Ship s : HelloApplication.allShips)
        {
            outStr += "\nShip: "+s.getName()+":\n";
            for(Container c : s.allContainers)
                outStr += c.toString()+"\n";
        }
        //displays all pallets on containers
        for (Container container : HelloApplication.allContainers) {
            outStr += "\nContainer: " + container.getNameContainer() + ":\n";
            for (Pallet p : container.allPallets) {
                outStr += p.toString() + "\n";
            }


            //displays all goods on pallets
            for (Pallet p : HelloApplication.allPallets) {
                outStr += "\nPallet: " + p.getGoodDescription() + ":\n";
                for (Good g : Pallet.allGoods)
                    outStr += g.toString() + "\n";
            }



            

        }
        // Set the content of the displayTextArea to the generated outStr
        displayTextArea.setText(outStr);

        // Set the font style of displayTextArea to Courier New with a font size of 12
        displayTextArea.setFont(new Font("Courier New", 12));

        // Make the displayTextArea read-only
        displayTextArea.setEditable(false);
    }

}


