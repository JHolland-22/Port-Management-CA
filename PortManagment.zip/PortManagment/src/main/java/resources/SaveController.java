package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Formatter;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class SaveController implements Initializable {


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
    public void savePortManagerDetails() {
        try {
            // Open the output stream to the file "AllPortShipInfo.txt"
            FileOutputStream fos = new FileOutputStream("AllPortShipInfo.txt");
            // Wrap the FileOutputStream with DataOutputStream for efficient writing
            DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));

            // Write details of all ports into the file
            for (Port port : allPorts) {
                outStream.writeUTF(port.toString() + "\n");
            }

            // Write details of all ships into the file
            for (Ship ship : allShips) {
                outStream.writeUTF(ship.toString() + "\n");
            }

            // Write details of all containers into the file
            for (Container container : allContainers) {
                outStream.writeUTF(container.toString() + "\n");
            }

            // Write details of all pallets into the file
            for (Pallet pallet : allPallets) {
                outStream.writeUTF(pallet.toString() + "\n");
            }

            // Write details of all goods into the file
            for (Good good : allGoods) {
                outStream.writeUTF(good.toString() + "\n");
            }

            // Close the output stream after writing all the details
            outStream.close();
        } catch (IOException e) {
            // In case of an exception, print the stack trace
            System.out.println(e.toString() + "\n");
        }
    }

        /* verify the results
        String result;
        FileInputStream fis = new FileInputStream(fileName);
        DataInputStream reader = new DataInputStream(fis);
        result = reader.readUTF();
        reader.close();

        assertEquals(value, result);



    public void savePortManagerDetailsOLD() {
        try
                (Formatter outFile = new Formatter()){

            for (Port port : allPorts)
            {
                outFile.format(port.toString());
            }


            for (Ship ship : allShips)
            {
                outFile.format(ship.toString());
            }


            for (Container container : allContainers)
            {
                outFile.format(container.toString());
            }


            for (Pallet pallet : allPallets)
            {
                outFile.format(pallet.toString());
            }



            for (Good good : allGoods)
            {
                outFile.format(good.toString());
            }

        }
        catch (Exception err)
        {
            System.out.println("Error information couldn't be saved");
            JOptionPane.showMessageDialog(null ,"Error information couldn't be saved");

        }
    }



         */
    @FXML
    void exitButtonHandler (ActionEvent event) throws Exception, IOException {

        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}