package resources;

import com.example.portmanagment.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class PalletAddController implements Initializable {

    @FXML
    private Button addPalletButton;

    @FXML
    private Button clearAllButton;

    @FXML
    private TextField cubicFeetTextField;

    @FXML
    private Button exitButton;

    @FXML
    private TextField nameTextField;

    @FXML
    private Label palletNameLabel;

    @FXML
    private Label palletQuantityLabel;

    @FXML
    private Label palletTotalCubicFeet;

    @FXML
    private Label palletTotalWeight;

    @FXML
    private Label palletUnitVLabel;

    @FXML
    private TextField quantityTextField;

    @FXML
    private TextField totalWeightTextField;

    @FXML
    private TextField unitVTextField;
    private String unitValue;


    @FXML
    void addPalletButtonHandler(ActionEvent event) {
        boolean dataValid = true;

        // Retrieve text values from TextFields
        String nameStr = nameTextField.getText().trim();
        String quantityStr = quantityTextField.getText().trim();
        String totalWeightStr = totalWeightTextField.getText().trim();
        String cubicFeetStr = cubicFeetTextField.getText().trim();

        // Validation for empty name
        if (nameStr.length() == 0) {
            JOptionPane.showMessageDialog(null, " Error: Name cannot be blank");
            dataValid = false;
        }

        // Proceed with validation if data is still valid
        if (dataValid == true) {
            // Validation for empty quantity
            if (quantityStr.length() == 0) {
                JOptionPane.showMessageDialog(null, " Error: quantity cannot be blank");
                dataValid = false;
            }

            // Validation for empty total weight
            if (dataValid == true) {
                if (totalWeightStr.length() == 0) {
                    JOptionPane.showMessageDialog(null, " Error: weight cannot be blank");
                    dataValid = false;
                }
            }

            Pallet pallet = null;

            // Validation for empty cubic feet
            if (dataValid == true) {
                if (cubicFeetStr.length() == 0) {
                    JOptionPane.showMessageDialog(null, " Error: cubic Feet cannot be blank");
                    dataValid = false;
                }
            }

            // If all data is valid, create a new Pallet object and add it to the list
            if (dataValid == true) {
                pallet = new Pallet(nameStr, quantityStr, getUnitValue(), totalWeightStr, cubicFeetStr);
                allPallets.add(pallet);
                JOptionPane.showMessageDialog(null, "Success Pallet Added");
            }
        }
    }


    @FXML
    void clearAllButtonHandler(ActionEvent event) {
        nameTextField.setText("");
        quantityTextField.setText("");
        totalWeightTextField.setText("");
        cubicFeetTextField.setText("");
    }

    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**
     * Calculates the cumulative unit value for all the pallets.
     * Iterates through each pallet in the 'allPallets' collection
     * and computes the unit value based on the quantity of goods
     * and the total weight of each pallet.
     * Accumulates these unit values to produce the overall unit value.
     *
     * @return A String representation of the total unit value for all pallets.
     */
    public String getUnitValue() {
        // Initialize the total unit value
        double totalUnitValue = 0.0;

        // Iterate through each pallet
        for (Pallet p : allPallets) {
            // Retrieve quantity of goods for the current pallet
            int goodQuantity = p.getGoodQuantity();

            // Retrieve total weight of the current pallet
            double totalWeightofPallet = p.getTotalWeightofPallet();

            // Calculate unit value for the current pallet
            double unitValue = goodQuantity * totalWeightofPallet;

            // Accumulate unit value to the total unit value
            totalUnitValue += unitValue;
        }

        // Return the total unit value as a String
        return String.valueOf(totalUnitValue);
    }



}




