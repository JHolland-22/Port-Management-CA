package resources;

import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allShips;

public class ShipDisplayAllController implements Initializable {

    @FXML
    private Button returnToMainMenu;

    @FXML
    private TextArea shipDisplayTextArea;


    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the text for display
        String outStr = "ID Name            Code               flagState" + "\n" + "--------  --------------------   --------------------   --------------------" + "\n";

        // Iterate through all ships
        for (Ship ship : allShips) {
            // Append ship details to the output string
            outStr += ship.toString() + "\n";
        }

        // Append the number of ships found
        outStr += " -> " + allShips.getSize() + " Ship found " + "\n";

        // Set the display text in the shipDisplayTextArea
        shipDisplayTextArea.setText(outStr);
        shipDisplayTextArea.setFont(new Font("Courier New", 12));
        shipDisplayTextArea.setEditable(false); // Set as read-only
    }
}
