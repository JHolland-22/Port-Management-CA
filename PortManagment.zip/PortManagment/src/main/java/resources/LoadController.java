package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import static com.example.portmanagment.HelloApplication.*;

public class LoadController implements Initializable {

    String result;

    public void loadPortManager() {
        // verify the results
        // Creating a FileInputStream to read from a file specified by the 'fileName' variable
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("Port");
            fis = new FileInputStream("Ship");
            fis = new FileInputStream("Container");
            fis = new FileInputStream("Pallet");
            fis = new FileInputStream("Good");


// Creating a DataInputStream to read data from the FileInputStream
            DataInputStream reader = new DataInputStream(fis);

// Reading UTF-encoded data from the DataInputStream and storing it in the 'result' variable
            result = reader.readUTF();

// Closing the DataInputStream
            reader.close();

// Asserting that the 'result' obtained from the file matches the 'value' (presumably expected value)
            equals(fis);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
        @FXML
        void exitButtonHandler (ActionEvent event) throws Exception, IOException {

            Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }




















    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}



 


