package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;
import static com.example.portmanagment.HelloApplication.allPorts;


public class GoodToPalletController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button clearInputs;
    @FXML
    private ComboBox<Good> goodComboBox;
    @FXML
    private ComboBox<Pallet> palletComboBox;
    @FXML
    private ComboBox<Container> containerComboBox;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private Button returnToMainMenu;


    @FXML
    void addButtonHandler(ActionEvent event) {

        Container c = containerComboBox.getValue();
        Pallet pa = palletComboBox.getValue(); // Get the selected pallet from palletComboBox
        Good g = goodComboBox.getValue(); // Get the selected good from goodComboBox
        if (c != null && pa != null && g != null) {
            c.allPallets.remove(pa);
            pa.allGoods.add(g);

            allGoods.remove(g);
            // Show a success message indicating the good was added to the pallet
            JOptionPane.showMessageDialog(null,
                    "Success: Good Added To Pallet!!\n" +
                            pa.allGoods.toString());
        } else {

            // Show an error message if either good or pallet is not selected
            JOptionPane.showMessageDialog(null, "Please select a Good and a Pallet.");
        }
    }


    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene (main menu)
        stage.show();
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Populate container combo box items and set action for selected container
        for (Container container : allContainers) {
            containerComboBox.getItems().addAll(container);
        }
        containerComboBox.setOnAction(e -> printSelectedContainer());

        // Populate pallet combo box items and set action for selected pallet
        for (Pallet pallet : allPallets) {
            palletComboBox.getItems().addAll(pallet);
        }
        palletComboBox.setOnAction(e -> printSelectedPallet());

        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        for (Port port : allPorts) {
            portComboBox.getItems().addAll(port);
        }
        portComboBox.setOnAction(e -> printSelectedPort());

    }

    private void printSelectedPallet() {
        // Print the selected pallet
        System.out.println(palletComboBox.getValue());
    }

    private void printSelectedContainer() {
        // Print the selected container and its associated pallet
        System.out.println("Container: " + containerComboBox.getValue() +
                ", pallet: " + palletComboBox.getValue());
    }

    private void printSelectedShip() {
        for (Container container : shipComboBox.getValue().allContainers) {
            containerComboBox.getItems().addAll(container);
        }

        // Set an action event for the shipComboBox selection
        containerComboBox.setOnAction(e -> printSelectedContainer());

    }

    private void printSelectedPort() {
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());
    }

}
