package resources;

public class Exception extends RuntimeException {

    public class portException extends RuntimeException {

        public portException() {
            this("Error: something has went wrong.");
        }

        public portException(String message) {
            super(message);
        }

        public portException(String message, Throwable cause) {
            super(message, cause);
        }

        public class shipException extends RuntimeException {

            public shipException() {
                this("Error: something has went wrong.");
            }

            public shipException(String message) {
                super(message);
            }

            public shipException(String message, Throwable cause) {
                super(message, cause);
            }


        }
        public class containerException extends RuntimeException {

            public containerException() {
                this("Error: something has went wrong.");
            }

            public containerException(String message) {
                super(message);
            }

            public containerException(String message, Throwable cause) {
                super(message, cause);
            }


        }
        public class palletException extends RuntimeException {

            public palletException() {
                this("Error: something has went wrong.");
            }

            public palletException(String message) {
                super(message);
            }

            public palletException(String message, Throwable cause) {
                super(message, cause);
            }


        }
        public class goodException extends RuntimeException {

            public goodException() {
                this("Error: something has went wrong.");
            }

            public goodException(String message) {
                super(message);
            }

            public goodException(String message, Throwable cause) {
                super(message, cause);
            }


        }

    }

}
