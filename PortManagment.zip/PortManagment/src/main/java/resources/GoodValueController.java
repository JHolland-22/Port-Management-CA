package resources;

import com.example.portmanagment.Good;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allGoods;
import static com.example.portmanagment.HelloApplication.sortByValueOfAGoods;

public class GoodValueController implements Initializable {

    @FXML
    private TextArea TextArea;

    @FXML
    private Button returnToMainMenuButton;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Create a string to hold the formatted output
        String outStr = "ID           Name            Description                    GoodId          Unit Value" + "\n" + "--------  --------------------   --------------------   --------------------" + "\n";
        HelloApplication.sortByValueOfAGoods();
        // Iterate through allGoods and append Unit Value of each Good to the output string
        for (Good good : allGoods) {
            outStr += good.toString();
        }

        // Append the count of allGoods and display the output in TextArea
        outStr += " -> " + allGoods.getSize() + " good found " + "\n";

        // Assuming "TextArea" is the name of your TextArea component, set its text, font, and editability
        TextArea.setText(outStr);
        TextArea.setFont(new Font("Courier New", 12));
        TextArea.setEditable(false); // set to read-only
    }




    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
}

