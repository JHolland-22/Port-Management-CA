package resources;

import com.example.portmanagment.Good;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import static com.example.portmanagment.HelloApplication.*;

public class SearchForAGoodController implements Initializable {


    @FXML
    private ComboBox<String> comboCategory;
    @FXML
    private ComboBox<String> comboSubCategory;

    @FXML
    private TableView<Good> tblView;
    @FXML
    private TableColumn<Good, Integer> idColumn;
    @FXML
    private TableColumn<Good, String> nameColumn;
    @FXML
    private TableColumn<Good, String> descriptionColumn;
    @FXML
    private TableColumn<Good, Double> unitValueColumn;

    @FXML
    private ListView resultsLV;

    @FXML
    private TextField searchTextField;



    public void initialize(URL location, ResourceBundle resources) {

    }


    @FXML
    void cmdSearch() {
        resultsLV.getItems().clear();
        for (Good g : allGoods) {
            System.out.println(searchTextField);
            if (searchTextField != null) {



      if (g.getgName() != null) {
      if (g.getgDescription() != null) {
       if (g.getgId() != null) {
       if (String.valueOf(g.getGoodQuantity()) != null) {
      if (String.valueOf(g.getuValue()) != null) {



          // Check if gName is not null and contains search text, then adds to results

      if (g.getgName().contains(searchTextField.getText())) {
      }            // Check if gName is not null and contains search text, then adds to results

          if (g.getgDescription().contains(searchTextField.getText())) {
          }            // Check if gdescription is not null and contains search text, then adds to results

          if (g.getgId().contains(searchTextField.getText())) {
              }            // Check if gId is not null and contains search text, then adds to results

          if (String.valueOf(g.getGoodQuantity()).contains(searchTextField.getText())) {
                  }            // Check if goodQuantity is not null and contains search text, then adds to results

          if (String.valueOf(g.getuValue()).contains(searchTextField.getText())) {
          }
        resultsLV.getItems().add(g.getgName());
          resultsLV.getItems().add(g.getgDescription());
          resultsLV.getItems().add(g.getgId());
          resultsLV.getItems().add(g.getuValue());
        }
        }
       }
       }
      }
     }
     }
    }








    @FXML
        void exitButtonHandler (ActionEvent event) throws Exception, IOException {

            Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }





// For test purposes - add a few products
           /* allGoods.add(new Good("fruit", "101", "fruit", "100"));
            allGoods.add(new Good("meat", "102", "chicken", "120"));
            allGoods.add(new Good("spices", "105", "spices", "200"));
            allGoods.add(new Good("sauces", "101", "sauces", "50"));

            TableColumn<Good, Integer> idColumn = new TableColumn<>("ID");
            idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

            TableColumn<Good, String> nameColumn = new TableColumn<>("NAME");
            nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

            TableColumn<Good, String> descriptionColumn = new TableColumn<>("DESCRIPTION");
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));


            TableColumn<Good, Double> unitValueColumn = new TableColumn<>("DESCRIPTION");
            unitValueColumn.setCellValueFactory(new PropertyValueFactory<>("description"));



            if (comboCategory != null) { // Check if comboCategory is not null
                comboCategory.getItems().clear(); // Clear existing items
                comboCategory.getItems().addAll(String.valueOf(allGoods)); // Add allGoods option
                comboCategory.setValue(String.valueOf(allGoods)); // Set allGoods as the default value
            }

            // Clear and set values for comboSubCategory
            if (comboSubCategory != null) { // Check if comboSubCategory is not null
                comboSubCategory.getItems().clear(); // Clear existing items
                comboSubCategory.getItems().addAll(String.valueOf(allGoods)); // Add allGoods option
                comboSubCategory.setValue(String.valueOf(allGoods)); // Set allGoods as the default value
            }


            updateTableView(allGoods);

            */
// allGoods = new good();  // initialise shop to a new (empty) collection of Products

// for test purposes -- add a few products
       /* allGoods.add(new Good("fruit","101","fruit","100"));
        allGoods.add(new Good("meat","102","chicken","120"));
        allGoods.add(new Good("spices","105","spices","200"));
        allGoods.add(new Good("sauces","101","sauces","50"));



            idColumn.setCellValueFactory(new PropertyValueFactory<Good, Integer>("id"));
            nameColumn.setCellValueFactory(new PropertyValueFactory<Good, String>("name"));
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<Good, String>("description"));
            unitValueColumn.setCellValueFactory(new PropertyValueFactory<Good, Double>("unit Value"));

        if (comboCategory != null) { // Check if comboCategory is not null
            comboCategory.getItems().clear(); // Clear existing items
            comboCategory.getItems().addAll(String.valueOf(allGoods)); // Add allGoods option
            comboCategory.setValue(String.valueOf(allGoods)); // Set allGoods as the default value
        }

        // Clear and set values for comboSubCategory
        if (comboSubCategory != null) { // Check if comboSubCategory is not null
            comboSubCategory.getItems().clear(); // Clear existing items
            comboSubCategory.getItems().addAll(String.valueOf(allGoods)); // Add allGoods option
            comboSubCategory.setValue(String.valueOf(allGoods)); // Set allGoods as the default value
        }

        updateTableView(allGoods);
        }

       /* public void changedCategoryCombo(ActionEvent e) throws Exception
        {
            tblView.setItems(allGoods.getSize(comboCategory.getValue(),comboSubCategory.getValue())));
        }

        public void changedSubCategoryCombo(ActionEvent e) throws Exception
        {
            tblView.setItems(allGoods.getSize());
        }


        */







