package resources;

import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.Ship.*;

public class LaunchDisplayController implements Initializable {


    @FXML
    private TextArea launchTextArea;

    @FXML
    private Button returnToMainMenuButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize the launchTextArea to display information about ships at sea

        // Start building the output string to display ship information
        String outStr = "Ship" + "\n" +
                "-------- -------------------- -------------------- -------------------- -------------------- --------------------" + "\n";

        // Iterate through all ships in HelloApplication.allShips
        for (Ship ship : HelloApplication.allShips) {
            // Append each ship's information to the output string
            outStr += ship.toString() + "\n";
        }

        // Add information about the total number of ships at sea
        outStr += " -> " + HelloApplication.allShips.getSize() + " ship at sea " + "\n";

        // Set the formatted string to the launchTextArea
        launchTextArea.setText(outStr);
        launchTextArea.setFont(new Font("Courier New", 12));
        launchTextArea.setEditable(false); // Set the TextArea as read-only
    }







    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file to create a new Parent root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new Scene using the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage from the event's source and set the newly created scene
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);

        // Show the stage to display the main menu
        stage.show();
    }

}


