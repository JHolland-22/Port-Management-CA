package resources;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;


import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allShips;

public class ShipAddController implements Initializable {

    @FXML
    private Button addShipButton;
    @FXML
    private Button clearAllButton;
    @FXML
    private TextField shipCodeTextField;
    @FXML
    private TextField shipCountryTextField;
    @FXML
    private Button exitButton;
    @FXML
    private TextField shipNameTextField;
    @FXML
    private Label shipCodeLabel;
    @FXML
    private Label shipCountryLabel;
    @FXML
    private Label shipNameLabel;




    @FXML
    void addShipButtonHandler(ActionEvent event) {
        // Initialize dataValid flag as true
        boolean dataValid = true;

        // Get and trim the input values from text fields
        String nameStr = shipNameTextField.getText().trim();
        String codeStr = shipCodeTextField.getText().trim();
        String countryStr = shipCountryTextField.getText().trim();

        // Validation for nameStr
        if (nameStr.length() == 0) {
            // Show an error message if the name is blank
            JOptionPane.showMessageDialog(null, " Error: Name cannot be blank");
            // Set dataValid to false as name is blank
            dataValid = false;
        }

        if (dataValid == true) {
            // Validation for codeStr
            if (codeStr.length() == 0) {
                // Show an error message if the code is blank
                JOptionPane.showMessageDialog(null, " Error: Code cannot be blank");
                // Set dataValid to false as code is blank
                dataValid = false;
            }

            Ship ship = null;

            if (dataValid == true) {
                // Validation for countryStr
                if (countryStr.length() == 0) {
                    // Show an error message if the country is blank
                    JOptionPane.showMessageDialog(null, " Error: Country cannot be blank");
                    // Set dataValid to false as country is blank
                    dataValid = false;
                }
                if (dataValid == true) {
                    // Create a new Ship object if all data is valid
                    ship = new Ship(nameStr, codeStr, countryStr);
                }
            }

            // Add the created ship to the 'allShips' collection
            allShips.add(ship);

            // Show a success message after adding the ship
            JOptionPane.showMessageDialog(null, "Success Ship Added");
        }
    }


    @FXML
    void clearAllButtonHandler(ActionEvent event)
    {

        shipNameTextField.setText("");
        shipCodeTextField.setText("");
        shipCountryTextField.setText("");

    }

    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception,IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        //allShips = new LinkyList<Ship>();
    }
}