package resources;

import com.example.portmanagment.Container;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.Pallet;
import com.example.portmanagment.Port;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class PalletRemoveController implements Initializable {

    @FXML
    private Button clearAllButton;

    @FXML
    private Button exitButton;

    @FXML
    private ComboBox<Pallet> palletComboBox;

    @FXML
    private ComboBox<Container> containerComboBox;

    @FXML
    private Button removePalletButton;


    @FXML
    void exitButtonHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }




    @FXML
    void removePalletButtonHandler(ActionEvent event) {
        Pallet pa = palletComboBox.getValue();
        Container c = containerComboBox.getValue();
        {
            c.allPallets.remove(pa);
            //pa.setContainer(c);
            allPallets.remove(pa);

            // Show a success message
            JOptionPane.showMessageDialog(null,
                    "Success: Pallet Removed To Container!!\n" +
                            c.allPallets.toString());
        }  {
            // Show an error message if either pallet or container is not selected
            JOptionPane.showMessageDialog(null, "Please select a Pallet and a Container");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the portComboBox with items from HelloApplication.allPorts
        for (Container container : allContainers) {
            containerComboBox.getItems().addAll(container);
        }

        // Set an action event for the portComboBox selection
        containerComboBox.setOnAction(e -> printSelectedContainer());
    }

    // Method triggered when a port is selected
    private void printSelectedContainer() {
        // Print the value of the selected port to the console
        System.out.println(containerComboBox.getValue());

        // Iterate through ships in the selected port and add them to shipComboBox items
        for (Pallet pallet : containerComboBox.getValue().allPallets) {
            palletComboBox.getItems().addAll(pallet);
        }

        // Set an action event for the shipComboBox selection
        palletComboBox.setOnAction(e -> printSelectedPallet());
    }

    // Method triggered when a ship is selected
    private void printSelectedPallet() {
        // Print the selected ship's value and its corresponding port to the console
        System.out.println("Pallet: " + palletComboBox.getValue() +
                ", Container: " + containerComboBox.getValue());
    }

    // Event handler for portComboBox action (currently empty)
    @FXML
    private void containerComboBox(ActionEvent event) {

    }



}



