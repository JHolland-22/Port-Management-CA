package resources;


import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;


public class LaunchAShip implements Initializable {


    @FXML
    private Button launchButton;
    @FXML
    private Button clearInputsButton;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private Button returnTomMainMenuButton;




    @FXML
    private TextArea launchTextArea;

    @FXML
    void launchButtonHandler(ActionEvent event) {
        launchTextArea = new TextArea(); // Creating a new TextArea (potentially not necessary)

        Port p = portComboBox.getValue();
        Ship s = shipComboBox.getValue();

        if (p.allShips != null) {
            p.allShips.remove(s); // Remove the ship from the list of ships in the port

            // Add the ship to the list of allShips (assuming allShips is a global list of all ships)
            allShips.add(s);

            // Show a success message indicating that the ship was launched
            JOptionPane.showMessageDialog(null,
                    "Success: Ship Launched!!\n" +
                            p.allShips.toString());
        } else {

            // Show an error message if either ship or port is not selected
            JOptionPane.showMessageDialog(null, "Please select a Ship and a Port.");
        }
    }




    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene (main menu)
        stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the portComboBox with items from HelloApplication.allPorts
        for (Port port : HelloApplication.allPorts) {
            portComboBox.getItems().addAll(port);
        }

        // Set an action event for the portComboBox selection
        portComboBox.setOnAction(e -> printSelectedPort());
    }

    // Method triggered when a port is selected
    private void printSelectedPort() {
        // Print the value of the selected port to the console
        System.out.println(portComboBox.getValue());

        // Iterate through ships in the selected port and add them to shipComboBox items
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());
    }

    // Method triggered when a ship is selected
    private void printSelectedShip() {
        // Print the selected ship's value and its corresponding port to the console
        System.out.println("Ship: " + shipComboBox.getValue() +
                ", Port: " + portComboBox.getValue());
    }

    // Event handler for portComboBox action (currently empty)
    @FXML
    private void portComboBox(ActionEvent event) {

    }


}