package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.allContainers;

public class DisplayAllContainersOnAPortController implements Initializable {


    @FXML
    private TextArea textArea;

    @FXML
    private Button returnToMainMenuButton;

    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        // Load the MainMenu.fxml file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }


    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize an empty string to store container information
        String outStr = "";

        // Iterate through allContainers to retrieve container information
        for (Container container : allContainers) {
            // Append each container's information to the output string
            outStr += container.toString() + "\n";
        }

        // Add a summary indicating the total number of containers found at a port
        outStr += " -> " + allContainers.getSize() + " Containers found \n";
        for(Port p : HelloApplication.allPorts) {
            outStr += "\nPort: " + p.getName() + ":\n";
            for (Container c : p.allContainers)
                outStr += c.toString() + "\n";
            for (Ship s : HelloApplication.allShips) {
                outStr += "\nShip: " + s.getName() + ":\n";
                for (Container c : s.allContainers)
                    outStr += c.toString() + "\n";
            }
        }
        // Set the generated output string to the textArea
        textArea.setText(outStr);

        // Set the font style of the textArea to Courier New with size 12
        textArea.setFont(Font.font("Courier New", 12));

        // Make the textArea read-only
        textArea.setEditable(false);
    }



}



