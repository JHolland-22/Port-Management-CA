package resources;

import com.example.portmanagment.Container;
import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.Port;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;

public class ContainerToShipController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button clearInputs;
    @FXML
    private ComboBox<Container> containerComboBox;
    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private Button returnToMainMenu;

    private Container Container;

@FXML private TextArea textArea;


    @FXML
    void addButtonHandler(ActionEvent event) {
        textArea = new TextArea(); // Creating a new TextArea

        // Get the selected Port and Container from ComboBoxes
        Port p = portComboBox.getValue();
        Ship s = shipComboBox.getValue();
        Container c = containerComboBox.getValue();

        if (p != null && s != null && c != null) {
            p.allContainers.remove(c);
            s.allContainers.add(c);
            //remove from overall list
            allContainers.remove(c);
            // Show a success message indicating the container was added to the port
            JOptionPane.showMessageDialog(null,
                    "Success: Container Added To Port!!\n" +
                            s.allContainers.toString());
        }else {

        // Show an error message if either ship or port is not selected
        JOptionPane.showMessageDialog(null, "Please select a Ship and a Container.");
    }

}

    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        // Load the MainMenu.fxml file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the containerComboBox with items from allContainers
        for (Container container : allContainers) {
            containerComboBox.getItems().addAll(container);
        }
        // Set an action to print selected container information when an item is selected
        containerComboBox.setOnAction(e -> printSelectedContainer());

        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        for (Port port : allPorts) {
            portComboBox.getItems().addAll(port);
        }
        // Set an action to print selected container and port information when an item is selected
        portComboBox.setOnAction(e -> printSelectedPort());
    }
    private void printSelectedShip() {
        System.out.println("Ship: " + shipComboBox.getValue() +
                ", Port: " + portComboBox.getValue());
    }

    // Method to print the selected container
    private void printSelectedContainer() {
        System.out.println(containerComboBox.getValue());
    }

    // Method to print the selected container and port
    private void printSelectedPort() {
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());
    }
    }

