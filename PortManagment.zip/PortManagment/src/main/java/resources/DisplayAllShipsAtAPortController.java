package resources;

import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.Port;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;



public class DisplayAllShipsAtAPortController implements Initializable {
    @FXML
    private TextArea dockTextArea;

    @FXML
    private Button returnToMainMenuButton;



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize an empty string to store information about ships and ports
        String outStr = "Ship + Port" + "\n" + "-------- -------------------- -------------------- -------------------- -------------------- --------------------" + "\n";

        // Iterate through allShips to retrieve information about each Ship
        for (Ship ship : HelloApplication.allShips) {
            // Append each Ship's information to the output string
            outStr += ship.toString() + "\n";
        }

        // Add a summary indicating the total number of ships and ports found

        outStr += " -> " + HelloApplication.allShips.getSize() + " ship and port found " + "\n";
        for(Port p : HelloApplication.allPorts)
        {
            outStr += "\nPort: "+p.getName()+":\n";
            for(Ship s : p.allShips)
                outStr += s.toString()+"\n";
        }

        // Set up the dockTextArea with the generated output string
        dockTextArea.setText(outStr);

        // Set the font style of dockTextArea to Courier New with a font size of 12
        dockTextArea.setFont(new Font("Courier New", 12));

        // Make the dockTextArea read-only
        dockTextArea.setEditable(false);
    }





    @FXML
    void returnToMainMenuButtonHandler(ActionEvent event) throws Exception, IOException {
        // Load the "MainMenu.fxml" file using FXMLLoader to get the root node
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));

        // Create a new scene with the loaded root node
        Scene scene = new Scene(root);

        // Get the current stage (window) from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the scene to the stage (window)
        stage.setScene(scene);

        // Show the updated stage with the new scene
        stage.show();
    }

}


