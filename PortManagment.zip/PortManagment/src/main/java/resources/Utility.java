/*package resources;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.Event;

import java.io.IOException;

public class Utility {
    //example use
    //Utility.changeToScene.(class, event,"myXLM.fxml");
    public static void changeToScene(Class aClass, Event aEvent, String sceneFileStr) throws Exception, IOException {
        Parent root = FXMLLoader.load(aClass.getResource(sceneFileStr));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) aEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
}

 */



