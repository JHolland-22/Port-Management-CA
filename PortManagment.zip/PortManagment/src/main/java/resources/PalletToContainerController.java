package resources;

import com.example.portmanagment.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;

import static com.example.portmanagment.HelloApplication.*;


public class PalletToContainerController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button clearInputs;

    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private ComboBox<Container> containerComboBox;
    @FXML
    private ComboBox<Pallet> palletComboBox;
    @FXML
    private Button returnToMainMenu;

    private Pallet pallet;


    @FXML
    void addButtonHandler(ActionEvent event) {

        Pallet pa = palletComboBox.getValue();
        Container c = containerComboBox.getValue();

         if (pa != null && c !=null){
            c.allPallets.add(pa);
            pa.setContainer(c);
            allPallets.remove(pa);

                 // adding the unit value of the pallet onto the container
             double pUnitValue = Double.parseDouble((pa.getUnitValue()));
             double cUnitValue = Double.parseDouble((c.getUnitValue()));
             c.setUnitValue(pUnitValue + cUnitValue);

            // Show a success message
            JOptionPane.showMessageDialog(null,
                    "Success: Pallet Added To Container!!\n" +
                            c.allPallets.toString());
        } else {
            // Show an error message if either pallet or container is not selected
            JOptionPane.showMessageDialog(null, "Please select a Pallet and a Container");
        }
    }





    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception, IOException {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    // Initializing ComboBoxes with values from allContainers and allPallets
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Adding items from allContainers to containerComboBox
        for (Container container : allContainers) {
            containerComboBox.getItems().addAll(container);
        }
        // Setting action for when an item is selected in containerComboBox
        containerComboBox.setOnAction(e -> printSelectedContainer());

        // Adding items from allPallets to palletComboBox
        for (Pallet pallet : allPallets) {
            palletComboBox.getItems().addAll(pallet);
        }
        // Setting action for when an item is selected in palletComboBox
        palletComboBox.setOnAction(e -> printSelectedPallet());

        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        for (Port port : allPorts) {
            portComboBox.getItems().addAll(port);
        }
        // Set an action to print selected container and port information when an item is selected
        portComboBox.setOnAction(e -> printSelectedPort());
    }


    // Method to print the selected pallet value
    private void printSelectedPallet() {
        System.out.println(palletComboBox.getValue());
    }

    // Method to print the selected container and pallet values
    private void printSelectedContainer() {
        System.out.println("Container: " + containerComboBox.getValue() +
                ", pallet: " + palletComboBox.getValue());
    }

    private void printSelectedShip() {
        for (Container container : shipComboBox.getValue().allContainers) {
            containerComboBox.getItems().addAll(container);
        }

        // Set an action event for the shipComboBox selection
        containerComboBox.setOnAction(e -> printSelectedContainer());

    }
    private void printSelectedPort() {
        for (Ship ship : portComboBox.getValue().allShips) {
            shipComboBox.getItems().addAll(ship);
        }

        // Set an action event for the shipComboBox selection
        shipComboBox.setOnAction(e -> printSelectedShip());
    }

}




