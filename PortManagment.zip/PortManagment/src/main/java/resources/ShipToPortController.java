package resources;

import com.example.portmanagment.HelloApplication;
import com.example.portmanagment.LinkyList;
import com.example.portmanagment.Port;
import com.example.portmanagment.Ship;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;
import static com.example.portmanagment.HelloApplication.allShips;
import static com.example.portmanagment.HelloApplication.allPorts;


public class ShipToPortController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button clearInputs;
    @FXML
    private ComboBox<Port> portComboBox;
    @FXML
    private ComboBox<Ship> shipComboBox;
    @FXML
    private Button returnToMainMenu;


    private Ship ship;


    @FXML
    void addButtonHandler(ActionEvent event) {
        // Get the selected port and ship
        Port p = portComboBox.getValue();
        Ship s = shipComboBox.getValue();

        // Add the ship to the port's list of ships
        if (s != null && p != null) {
            p.allShips.add(s);
            //remove from overall list
            allShips.remove(s);


            // Show a success message indicating the ship addition to the port
            JOptionPane.showMessageDialog(null,
                    "Success: Ship Added To Port!!\n" +
                            p.allShips.toString());
        } else {

            // Show an error message if either ship or port is not selected
            JOptionPane.showMessageDialog(null, "Please select a Ship and a Port.");

        }
    }




    @FXML
    void returnToMainMenuHandler(ActionEvent event) throws Exception , IOException
    {
        Parent root = FXMLLoader.load(HelloApplication.class.getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
       // Utility.changeToScene(getClass(), event, "MainMenu.fxml");

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Populate shipComboBox with all available ships
        for (Ship ship : HelloApplication.allShips) {
            shipComboBox.getItems().addAll(ship);
        }
        shipComboBox.setOnAction(e -> printSelectedShip());

        // Populate portComboBox with all available ports
        for (Port port : HelloApplication.allPorts) {
            portComboBox.getItems().addAll(port);
        }
        portComboBox.setOnAction(e -> printSelectedPort());
    }

    // Method to print the selected port
    private void printSelectedPort() {
        System.out.println(portComboBox.getValue());
    }

    // Method to print the selected ship along with the port
    private void printSelectedShip() {
        System.out.println("Ship: " + shipComboBox.getValue() +
                ", Port: " + portComboBox.getValue());
    }



    @FXML
    private void portComboBox(ActionEvent event)
    {

    }



}


