package com.example.portmanagment;


import static com.example.portmanagment.HelloApplication.allPallets;

public class Pallet {
    public static LinkyList<Good> allGoods = new LinkyList<>();
    public static LinkyList<Container> allContainers = new LinkyList<>();

    Container container; //container object brought in to access container name

    private String goodDescription;
    private String palletId;
    private int goodQuantity;
    private double unitValue;
    private double totalWeightofPallet ;
    private double totalSizeCubicFeet;


    //constructor to make add goods method work
    public Pallet(String goodDescription, int goodQuantity, double unitValue) {
        this.goodDescription = goodDescription;
        this.goodQuantity = goodQuantity;
        this.unitValue = unitValue;
    }

    //constructor


    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) { // Need to be able to set a pallets destination container.
        this.container = container;
    }

    public Pallet(String goodDescription, String palletId, int goodQuantity, double unitValue, double totalWeightofPallet, double totalSizeCubicFeet) {

        this.goodDescription = goodDescription;
        this.palletId = palletId;
        this.goodQuantity = goodQuantity;
        this.unitValue = unitValue;
        this.totalWeightofPallet = totalWeightofPallet;
        this.totalSizeCubicFeet = totalSizeCubicFeet;
    }

    //for java fx
    public Pallet(String nameStr, String quantityStr, String getUnitValue, String totalWeightStr, String cubicFeetStr) {
        this.goodDescription = nameStr;
        this.goodQuantity = Integer.parseInt(quantityStr);
        this.unitValue = Double.parseDouble(getUnitValue());
        this.totalWeightofPallet = Double.parseDouble(totalWeightStr);
        this.totalSizeCubicFeet = Double.parseDouble(cubicFeetStr);

    }

    //toString
    @Override
    public String toString() {

            return "Pallet{" +
                    "goodDescription='" + goodDescription + '\'' +
                    ", goodQuantity=" + goodQuantity +
                    ", unitValue=" + getUnitValue() +
                    ", totalWeightofPallet=" + totalWeightofPallet +
                    ", totalSizeCubicFeet=" + totalSizeCubicFeet + "In Container:" ;
                 //   container.getContainerId(); //get the name of the container the pallet is in

    }

    public String getGoodDescription() {
        return goodDescription;
    }

    public void setGoodDescription(String goodDescription) {
        this.goodDescription = goodDescription;
    }

    public int getGoodQuantity() {
        return goodQuantity;
    }

    public void setGoodQuantity(int goodQuantity) {
        this.goodQuantity = goodQuantity;
    }

    public String getUnitValue() {

        double totalUnitValue = 0.0;

        for (Pallet p : allPallets) {
            int goodQuantity = p.getGoodQuantity();

            double totalWeightofPallet = p.getTotalWeightofPallet();

            double unitValue = goodQuantity * totalWeightofPallet;

            totalUnitValue += unitValue;
        }
        return String.valueOf(totalUnitValue);
    }



    public void setUnitValue(double unitValue) {
        this.unitValue = unitValue;
    }

    public double getTotalWeightofPallet() {
        return totalWeightofPallet;
    }

    public void setTotalWeightofPallet(double totalWeightofPallet) {
        this.totalWeightofPallet = totalWeightofPallet;
    }

    public double getTotalSizeCubicFeet() {
        return totalSizeCubicFeet;
    }

    public void setTotalSizeCubicFeet(double totalSizeCubicFeet) {
        this.totalSizeCubicFeet = totalSizeCubicFeet;
    }

    public String getPalletId() {
        return palletId;
    }

    public void setPalletId(String palletId) {
        this.palletId = palletId;
    }

}


//methods


// public String addGoods(String goodDescription, int goodQuantity, double unitValue) {
//   Pallet addGood = new Pallet(goodDescription, goodQuantity, unitValue);
//  return "New good added" + addGood;
//}

   /* public String smartAddGoods() {
        // Check whether to add to a pallet or a container based on criteria.
        boolean addToPallet = addToPallet(goodDescription, goodQuantity, unitValue);
        if (addToPallet) {
            // Add the goods to a pallet and return a message.
            addPallet(goodDescription, goodQuantity, unitValue, totalWeightofPallet, totalSizeCubicFeet);
            return "Goods added to a pallet.";
        } else {
            // Add the goods directly to a container and return a message.
            addGoods(goodDescription, goodQuantity, unitValue);
            return "Goods added directly to a container.";
        }
    }
    private boolean addToPallet(String goodDescription, int goodQuantity, double unitValue) {
        //need to add stuff
        return true;
    }
*/