package com.example.portmanagment;

import javafx.scene.control.TextField;

import java.util.LinkedList;

import static com.example.portmanagment.HelloApplication.allPallets;
import static com.example.portmanagment.HelloApplication.allShips;

public class Port {



    private String name;
    private String internationalPortCode;
    private String country;


    private static int lastUsedPortID = 1000;

    private double unitValue;
    public  LinkyList<Ship> allShips = new LinkyList<>();
    public  LinkyList<Container> allContainers = new LinkyList<>();



    //constructor

    public Port(String nameStr){ //String internationalPortCode, String country, double unitValue) {
        this.name = nameStr;
      //  this.internationalPortCode = internationalPortCode;
        //this.country = country;
        //this.unitValue = unitValue;


    }

    public String getUnitValue() {

        double totalUnitValue = 0.0;

        for (Pallet p : allPallets) {
            int goodQuantity = p.getGoodQuantity();
            double totalWeightofPallet = p.getTotalWeightofPallet();

            double unitValue = goodQuantity * totalWeightofPallet;
            totalUnitValue += unitValue;
        }

        return String.valueOf(totalUnitValue);
    }


    public void setUnitValue(double unitValue) {
        this.unitValue = unitValue;
    }


    //FOR JAVAFX
    //public Port(TextField nameTextField, TextField codeTextField, TextField countryTextField) {
      //  this.name = String.valueOf(nameTextField);
        //this.internationalPortCode = String.valueOf(Integer.parseInt(String.valueOf(codeTextField)));
        //this.country = String.valueOf(countryTextField);
        //this.unitValue = Double.parseDouble(getUnitValue());
    //}


    //toString

    @Override
    public String toString() {
        return "Port{" +
                "name='" + name + '\'' +
               // ", internationalPortCode ='" + internationalPortCode + '\'' +
              //  ", country='" + country + '\'' +
                //", unitValue=" + unitValue+ '\'' +
                '}';
    }


    //methods


    //getters and setters

    public Port(String name, String code, String country) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getInternationalPortCode(String code) {
        return true;
    }

    public void setInternationalPortCode(String internationalPortCode) {
        this.internationalPortCode = internationalPortCode;
    }

    public String getInternationalPortCode() {
        return internationalPortCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }


    public static int getLastUsedPortID() {
        return lastUsedPortID;
    }

    public static void setLastUsedPortID(int lastUsedPortID) {
        Port.lastUsedPortID = lastUsedPortID;
    }

    public  LinkyList<Ship> getAllShips() {
        return allShips;
    }

}


