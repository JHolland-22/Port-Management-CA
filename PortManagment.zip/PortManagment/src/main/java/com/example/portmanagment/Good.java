package com.example.portmanagment;

import static com.example.portmanagment.HelloApplication.allGoods;

public class Good {

    private String gDescription;
    private String gName;
    private String gId;
    private String uValue;
    private double totalWeightofGood;
    private int goodQuantity;

    //FOR JAVA FX

    public Good(String nameStr, int gIdStr, String gDescriptionStr, int goodQuantity, double totalWeightofGood) {
        this.gDescription = gDescriptionStr;
        this.gName = nameStr;
        this.gId = String.valueOf(gIdStr);
        this.goodQuantity = goodQuantity;
        this.uValue = String.valueOf(totalWeightofGood);

    }

   /* public Good(String nameStr, int gIdStr, String gDescriptionStr, int goodQuantity, double totalWeightofGood) {
        //for adding a GOOD
        this.gDescription = gDescriptionStr;
        this.gName = nameStr;
        this.gId = gIdStr;
        this.uValue = unitVStr;
    }


    */
    public double getTotalWeightofGood() {
        return totalWeightofGood;
    }

    public void setTotalWeightofGood(double totalWeightofGood) {
        this.totalWeightofGood = totalWeightofGood;
    }

    public int getGoodQuantity() {
        return goodQuantity;
    }

    public void setGoodQuantity(int goodQuantity) {
        this.goodQuantity = goodQuantity;
    }

    public String getgDescription() {
        return gDescription;
    }

    public void setgDescription(String gDescription) {
        this.gDescription = gDescription;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }

    public String getgId() {
        return gId;
    }

    public void setgId(String gId) {
        this.gId = gId;
    }

    public double getuValue() {
        double totalUnitValue = 0.0;

        for (Good g : allGoods) {
            int goodQuantity = g.getGoodQuantity();
            double totalWeightofGood = g.getTotalWeightofGood();

            double unitValue = goodQuantity * totalWeightofGood;
            totalUnitValue += unitValue;
        }

        return Double.parseDouble(String.valueOf(totalUnitValue));
    }


    public void setuValue(String uValue) {
        this.uValue = uValue;
    }

    @Override
    public String toString() {

        return "Good{" +
                ", gName='" + gName + '\'' +
                "gDescription='" + gDescription + '\'' +
                ", gId='" + gId + '\'' +
                ", UValue=" + getuValue() +
                '}';
    }


    public double setuValue() {
        return 0;
    }

    public double getUValue() {
        return 0;
    }
}
