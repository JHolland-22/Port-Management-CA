package com.example.portmanagment.Utils;

public interface iSterilaizer
{
    void save() throws Exception;
    void load() throws Exception;
    String fileName();
}
