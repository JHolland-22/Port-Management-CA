package com.example.portmanagment;

import static com.example.portmanagment.HelloApplication.allContainers;

public class Container {


    public LinkyList<Pallet>allPallets = new LinkyList<>();




    private static Container containerNode;
    private String headContainer = null;
    public static Container next = null;

    public String containerId;
    private static String nameContainer;

    private static String nextPallet;
    private static int sizeContainer;
    private double unitValue;

    private double totalWeightofPallet;
    private double totalSizeCubicFeet ;


    //constructor for scene builder addContainer method


    public Container(String nameStr, String codeStr, String sizeStr) {
        this.nameContainer = nameStr;
        this.containerId = codeStr;
        this.sizeContainer = Integer.parseInt(sizeStr);
        this.unitValue = Double.parseDouble(getUnitValue());

    }


    public String getHeadContainer() {
        return headContainer;
    }

    public void setHeadContainer(String headContainer) {
        this.headContainer = headContainer;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        containerId = containerId;
    }





    //toString

    @Override
    public  String toString() {
        return
                ", nameContainer='" + nameContainer + '\'' +
                ", idContainer='" + containerId + '\'' +
                        ", unit Value='" + unitValue + '\'' +
                ", sizeContainer=" + totalSizeCubicFeet +
                '}';
    }


    public String getUnitValue() {

        double totalUnitValue = 0.0;

        for (Pallet p : allPallets) {
            int goodQuantity = p.getGoodQuantity();
            double totalWeightofPallet = p.getTotalWeightofPallet();

            double unitValue = goodQuantity * totalWeightofPallet;
            totalUnitValue += unitValue;
        }

        return String.valueOf(totalUnitValue);
    }


    public void setUnitValue(double unitValue) {
        this.unitValue = unitValue;
    }





    //getters and setters

    public Container getNext() {
        return next;
    }

    public void setNext(Container next) {
        this.next = next;
    }

    public String getNameContainer() {
        return nameContainer;
    }

    public void setNameContainer(String nameContainer) {
        this.nameContainer = nameContainer;
    }


    public String getNextPallet() {
        return nextPallet;
    }

    public void setNextPallet(String nextPallet) {
        this.nextPallet = nextPallet;
    }

    public double getSizeContainer() {

        double totalSizeCubicFeet = 0.0;

        for (Container c : allContainers) {
            totalSizeCubicFeet = c.totalSizeCubicFeet();

            double sizeContainer = c.getTotalSizeCubicFeet() * 8 * 8;

            totalSizeCubicFeet += sizeContainer;
        }

        return Double.parseDouble(String.valueOf(totalSizeCubicFeet));
    }
    // this method is used to get the size of the container which is 8 x 8 and whatever nunber is entered after


    private double totalSizeCubicFeet() {
        return 0;
    }

    public void setSizeContainer(int sizeContainer) {
        this.sizeContainer = sizeContainer;
    }

    public Container getContainerNode() {
        return containerNode;
    }

    public void setContainerNode(Container containerNode) {
        this.containerNode = containerNode;
    }

    public LinkyList<Pallet> getAllPallets() {
        return allPallets;
    }

    public void setAllPallets(LinkyList<Pallet> allPallets) {
        this.allPallets = allPallets;
    }

    public double getTotalWeightofPallet() {
        return totalWeightofPallet;
    }

    public void setTotalWeightofPallet(double totalWeightofPallet) {
        this.totalWeightofPallet = totalWeightofPallet;
    }

    public double getTotalSizeCubicFeet() {
        return totalSizeCubicFeet;
    }

    public void setTotalSizeCubicFeet(double totalSizeCubicFeet) {
        this.totalSizeCubicFeet = totalSizeCubicFeet;
    }
}






