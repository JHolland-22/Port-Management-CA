package com.example.portmanagment;

import javafx.application.Application;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

public class HelloApplication extends Application {
    public static LinkyList<Port> allPorts = new LinkyList<>();
    public static LinkyList<Ship> allShips = new LinkyList<>();
    public static LinkyList<Container> allContainers = new LinkyList<>();
    public static LinkyList<Pallet> allPallets = new LinkyList<>();

    public static LinkyList<Good> allGoods = new LinkyList<>();




    public static void main(String[] args) {
        launch();
        }


    public static void addPort(String name, String code, String country) {
        // Creating a new Port object with provided parameters
        Port port = new Port(name, code, country);

        // Adding the newly created Port object to the allPorts collection
        HelloApplication.allPorts.add(port);

        // Initializing a variable 'size' with value 1
        int size = 1;

        // Looping until 'size' is less than the size of allPorts
        while (size < allPorts.getSize()) {
            // Printing the current value of 'size'
            System.out.println(size);
            // Incrementing 'size' by 1 in each iteration
            size++;
        }

        // Printing the contents of the allPorts collection
        System.out.println(allPorts);
    }


    public static void addShip(String name, String headShip, String nextContainer, String shipId, String flagState) {
        Ship ship = new Ship(name, headShip, nextContainer, shipId, flagState);
        HelloApplication.allShips.add(ship);
        int size = 1;
        while (size < allShips.getSize()) {
            System.out.println(size);
            size++;

        }
        System.out.println(allShips);

    }

    public static void addContainer(String nameStr, String codeStr, String sizeStr) {
        Container container = new Container(nameStr, codeStr, sizeStr);
        HelloApplication.allContainers.add(container);
        int size = 1;
        while (size < allContainers.getSize()) {
            System.out.println(size);
            size++;

        }
        System.out.println(allContainers);

    }

    public static void addPallet(String goodDescription, int goodQuantity, double unitValue) {
        Pallet pallet = new Pallet(goodDescription, goodQuantity, unitValue);
        HelloApplication.allPallets.add(pallet);
        int size = 1;
        while (size < allPallets.getSize()) {
            System.out.println(size);
            size++;

        }
        System.out.println(allPallets);

    }

    public static void addGood( String gDescription, int gId,String gName ,int goodQuantity, double totalWeightofGood) {
        Good good = new Good( gDescription, gId,gName , goodQuantity, totalWeightofGood);
        HelloApplication.allGoods.add(good);
        int size = 1;
        while (size < allGoods.getSize()) {
            System.out.println(size);
            size++;

        }
        System.out.println(allGoods);

    }

    public static void listPorts() {
        // Iterating through each Port object in the allPorts collection using an enhanced for loop
        for (Port p : allPorts) {
            // Printing each Port object using its 'toString()' method or its representation
            System.out.println(p);
        }
    }


    public static void listShips() {
        for (Ship s : allShips) {
            System.out.println(s);
        }
    }

    public static void listContainers() {
        for (Container c : allContainers) {
            System.out.println(c);
        }
    }

    public static void listPallets() {
        for (Pallet p0 : allPallets) {
            System.out.println(p0);
        }
    }

    public static void listGoods() {
        for (Good g : allGoods) {
            System.out.println(g);
        }

    }


    public static void deleteShipByShipId(String code) {
        listShips();
        for (Ship ship : allShips) {
            if (ship.getShipId().equalsIgnoreCase(code)) ;
            HelloApplication.allShips.remove(ship);
            String info = "Ship" + ship + "Deleted";
            System.out.println(info);
        }

    }

    public static void deletePortByCode(String code) {
        listPorts();
        for (Port port : allPorts) {
            if (port.getInternationalPortCode(code)) ;
            HelloApplication.allPorts.remove(port);
            String info = "Port" + port + "Deleted";
            System.out.println(info);
        }

    }

    public static void deleteContainerByCode(String code) {
        listContainers();
        for (Container container : allContainers) {
            if (container.getContainerId().equalsIgnoreCase(code)) ;
            HelloApplication.allContainers.remove(container);
            String info = "Container" + container + "Deleted";
            System.out.println(info);
        }

    }
    public static void deletePalletByCode(String code) {
        listPallets(); // Assuming this method lists the pallets, showing their details

        for (Pallet pallet : allPallets) {
            if (pallet.getPalletId().equalsIgnoreCase(code)) ; // Potential issue: The semicolon terminates the if statement prematurely

            // The next line, intended to remove the pallet, is not properly enclosed in braces
            HelloApplication.allPallets.remove(pallet); // Removing the pallet from the collection

            // The deletion information might not correspond to the correct deletion action due to the semicolon issue
            String info = "Pallet " + pallet + " Deleted"; // Creating deletion information
            System.out.println(info); // Printing deletion information
        }
    }


    public static void deleteGoodByCode(String code) {
        listGoods();
        for (Good good : allGoods) {
            if (good.getgId().equalsIgnoreCase(code)) ;
            HelloApplication.allGoods.remove(good);
            String info = "Good" + good + "Deleted";
            System.out.println(info);
        }

    }

    public static void getShipsLocations(String name) {
        listShips(); // Displays details of ships
        listPorts(); // Displays details of ports

        for (Port port : allPorts) {
            // Checks if the current port's name matches the provided 'name' parameter
            if (port.getName().equalsIgnoreCase(name)) {
                System.out.println("Port: " + port.getName()); // Prints the name of the matching port

                // Searches for ships at this port
                for (Ship ship : allShips) {
                    // Checks if the ship's current location matches the port's name
                    if (ship.getCurLocation().equalsIgnoreCase(port.getName())) {
                        System.out.println("Ship Location: " + ship.getName()); // Prints ship's location
                    } else {
                        System.out.println("Ship Location is at Sea"); // Prints when no ship is at this port
                    }
                    System.out.println("No matching ships found."); //prints when no ships found
                }
            }
        }
    }


    public static void viewAllGoods(String gDescription) {
        listGoods(); // Displays details of goods

        for (Good good : allGoods) {
            if (good.getgName().equalsIgnoreCase(gDescription)) {
                System.out.println("Good : " + good.getgDescription()); // Prints the description of the matching Good
            }
            System.out.println("No matching goods found.");
        }
    }
    public static boolean searchForAGood(String gName, String gDescription, String gId) {
        listGoods(); // Displays details of goods
        listPallets(); // Displays details of pallets

        for (Good good : allGoods)
            for (Pallet pallet: allPallets) // Missing opening brace for the for-loop

            {
                if (gDescription == pallet.getGoodDescription()) ; // Incorrect semicolon terminates the if statement

                // The below lines are commented out, affecting the core logic of the search
                if (good.getgName().equalsIgnoreCase(gName) &&
                        good.getgDescription().equalsIgnoreCase(gDescription) &&
                        good.getgId().equalsIgnoreCase(gId)) {

                    // Print details of the matching Good
                    // The printed details might not correspond to the correct matching Good due to commented code
                    System.out.println("Good:");
                    System.out.println("Name: " + good.getgName());
                    System.out.println("Description: " + good.getgDescription());
                    System.out.println("ID: " + good.getgId());
                    System.out.println("Quantity: " + pallet.getGoodQuantity());

                    return true;
                    // Missing closing brace for the commented if statement
                }
            }

        return false; // Incorrect placement of return statement
    }





    public static void swapGoods(LinkyList<Good> allGoods, double value1, double value2) {
        // Loop through all goods in the LinkyList
        for (Good good : allGoods) {
            // If the current good has a uValue equal to value1
            if (good.setuValue() == value1) {
                // Initialize good1 to the current good with uValue equal to value1
                Good good1 = null; // Declaration of good1, initialized as null
                good1 = good; // Assigning the current good to good1
            }
            // If the current good has a uValue equal to value2
            if (good.setuValue() == value2) {
                // Initialize good2 to the current good with uValue equal to value2
                Good good2 = null; // Declaration of good2, initialized as null
                good2 = good; // Assigning the current good to good2
            }
            // Redefinition of good1 and good2 variables to null
            Good good1 = null;
            Good good2 = null;
            if (good1 != null && good2 != null) ;

            int i = 0;
            //  setting uValue of good1 to uValue of good2 and vice versa
            good1.setuValue(String.valueOf(good2.getuValue()));
            good2.setuValue(String.valueOf(good1.getuValue()));
        }
    }


    public static double sortByValueOfAGoods() {
        listGoods(); // Display details of goods
        for (Good good : allGoods) {
            for (int i = allGoods.getSize() - 1; i >= 0; i--) {
                int highestIndex = i;
                for (int j = i + 1; j < allGoods.getSize(); j++) {
                    // Comparison within nested loops to find the highest value index
                    if (good.getuValue() < good.getuValue()) {
                        highestIndex = j;
                    }
                }
                // Swap the goods if the highestIndex is not the current index 'i'
                if (highestIndex != i) {
                    swapGoods(allGoods, i, highestIndex);
                }
            }
        }
        return 0;
    }


    public void smartAddGoods(String goodDescription, int goodQuantity, int unitValue, Port port, char[] code) {
        listContainers(); // Display details of containers

        for (Container container : allContainers) {
            if (container != null) {
                // Create a new pallet with the provided goods details
                Pallet pallet = new Pallet(goodDescription, goodQuantity, unitValue);

                // Add the created pallet to the 'allPallets' collection
                HelloApplication.allPallets.add(pallet);

                // Print the message indicating goods added to the container at the port
                System.out.println("Goods added to the container " + container.getContainerId() +
                        " at the port  " + port.getInternationalPortCode(String.valueOf(code)));
            } else {
                // Print a message if no container is found
                System.out.println("No container found.");
            }
        }
    }


    //@Override


    public static void loadContainer(String nameStr, String codeStr, String sizeStr, Port port, int code) {
        listShips();
        for (Ship ship : allShips) {
            if (ship == null) {
                Container container = new Container( nameStr, codeStr, sizeStr);
                HelloApplication.allContainers.add(container);
                System.out.println("container added to the ship " + ship.getShipId() +
                        " at the port  " + port.getInternationalPortCode(String.valueOf(code)));
            } else {
                System.out.println("No container found.");
            }
        }

    }


    public static void unloadContainer(Container container, Port port, String code) {
        listShips();
        for (Ship ship : allShips) {
            if (ship != null) {
               deleteContainerByCode(code);
                HelloApplication.allContainers.remove(container);
                System.out.println("container removed from the ship " + ship.getShipId() +
                        " at the port  " + port.getInternationalPortCode(code));
            } else {
                System.out.println("No container found.");
            }
        }

    }

    @Override
    public void start(Stage stage) throws Exception {

    }



































/*
    private int mainMenu() {
        System.out.println("""
                 -------Vehicle Store-------------
                |  1) Port Create/Remove MENU    |
                |  2)Ship Create/Remove MENU     |
                |  3)Container Create/Remove MENU| 
                |  4)Pallet Create/Remove MENU   |
                |  5)Good Create/Remove MENU     |
                |--------------------------------|
                |  6) Search for a Good          |
                |  7) Sort Good by Value         |  
                |  8) Smart Add Goods            | 
                |--------------------------------|
                |  9)  Save all                  |
                | 10)  Load all                  |
                |--------------------------------|
                |  0) Exit                       |
                 --------------------------------""");
        return ScannerInput.readNextInt("==>> ");
    }

    private void runMainMenu() {
        int option = mainMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> runPortMenu();
                case 2 -> runShipMenu();
                case 3 -> runContainerMenu();
                case 4 -> runPalletMenu();
                case 5 -> runGoodMenu();
                case 6 -> runSearchMenu();
                case 7 -> runSortMenu();
                case 8 -> runSmartMenu();
             //   case 9 ->();
             //   case 10 -> () ;
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = mainMenu();
        }

    }


    private int PortMenu() {
        System.out.println("""
                 --------Port  Menu---------
                |  1) Add a Port                   |
                |  2) Delete a Port                |
                |  3) List all Port                |
                |                                  |
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runPortMenu() {
        int option = PortMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addPort();
                case 2 -> deletePortByCode();
                case 3 -> listShips();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = PortMenu();
        }
    }

    private int ShipMenu() {
        System.out.println("""
                 --------Ship  Menu---------
                |  1) Add a Ship                   |
                |  2) Delete a Ship                |
                |  3) List all Ship                |
                |                                  |
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runShipMenu() {
        int option = ShipMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addShip();
                case 2 -> deleteShipByShipId();
                case 3 -> listShips();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = ShipMenu();
        }
    }
    private int ContainerMenu() {
        System.out.println("""
                 --------Container  Menu---------
                |  1) Add a Container              |
                |  2) Delete a Container           |
                |  3) List all Container           |
                |                                  |
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runContainerMenu() {
        int option = ContainerMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addContainer();
                case 2 -> deleteContainerByCode();
                case 3 -> listContainers();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = ContainerMenu();
        }
    }


    private int PalletMenu() {
        System.out.println("""
                 --------Pallet      Menu---------
                |  1) Add a Pallet                 |
                |  2) Delete a Pallet              |
                |  3) List all Pallet              |
                |                                  |
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runPalletMenu() {
        int option = PalletMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addPallet();
                case 2 -> deletePalletByCode();
                case 3 -> listPallets();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = PalletMenu();
        }
    }


    private int GoodMenu() {
        System.out.println("""
                 --------Good  Menu---------
                |  1) Add a Good                   |
                |  2) Delete a Good                |
                |  3) List all Good                |
                |                                  |
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runGoodMenu() {
        int option = GoodMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addGood();
                case 2 -> deleteGoodByCode();
                case 3 -> viewAllGoods();

                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = GoodMenu();
        }
    }


    private int SearchMenu() {
        System.out.println("""
                 --------Good  Menu---------
                |  1) Search for a Good            |
                |                                  |                                           
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runSearchMenu() {
        int option = SearchMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> searchForAGood();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = SearchMenu();
        }
    }
    private int SortMenu() {
        System.out.println("""
                 --------Good  Menu---------
                |  1) Sort a good by value         |
                |                                  |                                           
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runSortMenu() {
        int option = SortMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> sortByValueOfAGoods();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = SortMenu();
        }
    }
    private int SmartMenu() {
        System.out.println("""
                 --------Good  Menu---------
                |  1) Smart Add Goods              |
                |                                  |                                           
                |  0) Return to main menu          |
                 ----------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runSmartMenu() {
        int option = SmartMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> smartAddGoods();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = SmartMenu();
        }
    }
































    private class ScannerInput {
        public static int readNextInt(String prompt) {
            do {
                var scanner = new Scanner(System.in);
                try {
                    System.out.print(prompt);
                    return Integer.parseInt(scanner.next());
                }
                catch (NumberFormatException e) {
                    System.err.println("\tEnter a number please.");
                }
            }  while (true);
        }

        /**
         * Read a double from the user.  If the entered data isn't actually a double,
         * the user is prompted again to enter the double.
         *
         * @param prompt  The information printed to the console for the user to read
         * @return The number read from the user and verified as a double.

        public static double readNextDouble(String prompt) {
            do {
                var scanner = new Scanner(System.in);
                try{
                    System.out.print(prompt);
                    return Double.parseDouble(scanner.next());
                }
                catch (NumberFormatException e) {
                    System.err.println("\tEnter a number please.");
                }
            }  while (true);
        }
        /**
         * Read a float from the user.  If the entered data isn't actually a float,
         * the user is prompted again to enter the float.
         *
         * @param prompt  The information printed to the console for the user to read
         * @return The number read from the user and verified as a double.

        public static float readNextFloat(String prompt) {
            do {
                var scanner = new Scanner(System.in);
                try{
                    System.out.print(prompt);
                    return Float.parseFloat(scanner.next());
                }
                catch (NumberFormatException e) {
                    System.err.println("\tEnter a number please.");
                }
            }  while (true);
        }

        /**
         * Read a line of text from the user.  There is no validation done on the entered data.
         *
         * @param prompt  The information printed to the console for the user to read
         * @return The String read from the user.
         */
    /*
        public static String readNextLine(String prompt) {
            Scanner input = new Scanner(System.in);
            System.out.print(prompt);
            return input.nextLine();
        }

        /**
         * Read a single character of text from the user.  There is no validation done on the entered data.
         *
         * @param prompt  The information printed to the console for the user to read
         * @return The char read from the user.




        public static char readNextChar(String prompt) {
            Scanner input = new Scanner(System.in);
            System.out.print(prompt);
            return input.next().charAt(0);
        }
*/

    }






































