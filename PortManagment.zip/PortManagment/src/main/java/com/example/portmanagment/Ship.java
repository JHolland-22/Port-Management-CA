package com.example.portmanagment;


import java.util.LinkedList;

public class  Ship {

    public Ship next = null;


    public String curLocation;



    private String name;
    private String headShip;
    private String nextContainer;
    private String shipId;
    private String flagState;

    private int shippyId;
    private static int lastUsedShippyId = 1000;

    public  LinkyList<Container> allContainers = new LinkyList<>();



//constructors

    public Ship(String name, String shipId, String flagState, String id, String state) {
        shippyId = lastUsedShippyId;
        lastUsedShippyId++;

        this.name = name;
        this.shipId = shipId;
        this.flagState = flagState;
       allContainers = allContainers;
    }

    public Ship(String nameStr, String shipId, String flagState) {
        shippyId = lastUsedShippyId;
        lastUsedShippyId++;

        this.name = nameStr;
        this.shipId = shipId;
        this.flagState = flagState;
    }

    public Ship(LinkyList<Ship> allShips, LinkyList<Port> allPorts) {

    }


    //toString

    @Override
    public String toString() {
        return "Ship{" +
                ", name='" + name + '\'' +
                ", shipId='" + shipId + '\'' +
                ", flagState='" + flagState + '\'' +

                '}';
    }


//methods



  //  public String launchShip(String flagState) {
    ///    for ("Ship".equals(flagState));{
       //     return "Ship  is already launched!";
        //}{setFlagState("New Location for ship");
         //   System.out.println("Ship has been launched!");
        //}
    //}

    //  public String dockShip(String flagState) {
    ///    for ("Ship"!=equals(flagState));{
    //     return "Ship  is launched!";
    //}{setFlagState("New Location for ship");
    //   System.out.println("Ship has been docked!");
    //}
    //}

    public String getCurLocation() {
        return curLocation;
    }

    public void setCurLocation(String curLocation) {
        this.curLocation = curLocation;
    }

    public Ship getNext() {
        return next;
    }

    public void setNext(Ship next) {
        this.next = next;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHeadShip() {
        return headShip;
    }

    public void setHeadShip(String headShip) {
        this.headShip = headShip;
    }

    public String getNextContainer() {
        return nextContainer;
    }

    public void setNextContainer(String nextContainer) {
        this.nextContainer = nextContainer;
    }

    public String getShipId() {
        return shipId;
    }

    public void setShipId(String shipId) {
        this.shipId = shipId;
    }

    public String getFlagState() {
        return flagState;
    }

    public void setFlagState(String flagState) {
        this.flagState = flagState;
    }

    public int getShippyId() {
        return shippyId;
    }

    public void setShippyId(int shippyId) {
        this.shippyId = shippyId;
    }


    public static int getLastUsedShippyId() {
        return lastUsedShippyId;
    }

    public static void setLastUsedShippyId(int lastUsedShippyId) {
        Ship.lastUsedShippyId = lastUsedShippyId;
    }

    public LinkyList<Container> getAllContainers() {
        return allContainers;
    }

    public void setAllContainers(LinkyList<Container> allContainers) {
        this.allContainers = allContainers;
    }

  /*  public static LinkyList<Ship> getAtSea() {
        return AtSea;
    }

    public static void setAtSea(LinkyList<Ship> atSea) {
        AtSea = atSea;
    }

    public static LinkyList<Ship> getDocked() {
        return Docked;
    }

    public static void setDocked(LinkyList<Ship> docked) {
        Docked = docked;
    }
*/}











